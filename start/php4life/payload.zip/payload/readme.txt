Oh no! someone has added '69' to all big endian integers and the video is corrupt! subtract 69 from every four bytes in 420 seconds or you'll never see it!
